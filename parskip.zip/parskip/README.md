# parskip package

-----

This package is a reimplementation (with extensions) of a package with
the same name written by Hubert Partl in 1989 and later maintained by
Robin Fairbairns.

Package source can be found below:

https://github.com/FrankMittelbach/fmitex-parskip

The license is LPPL.

-----

Copyright (C) 2018-2021 Frank Mittelbach<br />
<https://latex-project.org/> <br />
All rights reserved.


